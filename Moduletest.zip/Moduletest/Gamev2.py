import fileroutes
import functions
import room1
import room_hallchoice
import room_westhall
import room_easthall
import room_sewer
import room_sacrifice
import room_field
import room_guard
import room_backhall
import room_exitchoice
import room_valley
import room_statue
import room_treasure
door_hall=[]
health=room1.health
interactions=['look','look around','examine','use','pray','play','eat','drink','open','check','speak','talk','listen','hit','break','punch','attack','fight','kill','hug','fuck','bang','light','go','move','walk','unlock','knock','swim','health','inventory','take','grab','drop','west','east','north','south','back','instructions']
location='room 1'
room_1=room1.room_1
hall_choice=room_hallchoice.hall_choice
west_hall=room_westhall.west_hall
east_hall=room_easthall.east_hall
sewer=room_sewer.sewer
sacrifice=room_sacrifice.sacrifice
field=room_field.field
guard_post=room_guard.guard_post
backhall=room_backhall.backhall
exitchoice=room_exitchoice.exitchoice
valley=room_valley.valley
statue=room_statue.statue
treasure=room_treasure.treasure
def choice_verify(n):
    while n!='death':
        location=room1.location
        print(" ")
        if health==[]:
            player_choice=functions.death(health)
        if location=='room 1':
            player_choice,action,item=room_1(location)
        if location=='hall choice':
            player_choice,action,item=hall_choice(location)
        if location=='west hall':
            player_choice,action,item=west_hall(location)
        if location=='east hall':
            player_choice,action,item=east_hall(location)
        if location=='sewer':
            player_choice,action,item=sewer(location)
        if location=='sacrifice':
            player_choice,action,item=sacrifice(location)
        if location=='field':
            player_choice,action,item=field(location)
        if location=='guard post':
            player_choice,action,item=guard_post(location)
        if location=='back hall':
            player_choice,action,item=backhall(location)
        if location=='exit choice':
            player_choice,action,item=exitchoice(location)
        if location=='valley':
            player_choice,action,item=valley(location)
        if location=='statue':
            player_choice,action,item=statue(location)
        if location=='treasure':
            player_choice,action,item=treasure(location)
        if player_choice.count(' ')==1 and (player_choice[0])!=' ':
            if action not in (interactions):
                print("I don't understand '",action,"' as a verb.")
        if player_choice.count(' ')>1:
            if 'to' in player_choice.split() or 'the' in player_choice.split() or 'at' in player_choice.split():
                print("I don't understand articles, such as 'to', 'the', and 'at'.")
            else:
                print("That command was too complicated for me to understand.")
        if player_choice.count(' ')==0:
            if player_choice not in (interactions):
                print("I don't recognize '",player_choice,"' as a verb.")
        functions.random_descrip(1,51)
        functions.health_tracker(health)
        print(" ")
    if n=='death':
        print(" ")
print(fileroutes.instructions)
print(" ")
game_start=str.lower(input("Welcome to the game. Are you ready to play?: "))
while game_start not in ['y','yes']:
    game_start=str.lower(input("Are you ready yet?: "))
if game_start in ['y','yes']:
    print(" ")
    print(fileroutes.start_room_text)
choice_verify(location)            
        
        
    
