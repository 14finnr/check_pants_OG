import random
from random import choices
from random import choice
import fileroutes
inventory=[]
first_dice=[]
dice=[]
guard=[]
def instructions(n):
    if 'instructions' in (n):
        print(fileroutes.instructions)
def take_damage(n):
    if len(n)>=1:
        n.remove(max(n))
def inv_check(n):
    if 'inventory' in (n):
        print("You have ",sorted(inventory)," in your inventory.")
def health_tracker(n):
    for i in range(1,11):
        if (n)!=[]:
            if i==max(n):
                print(" ")
                print("You currently have ",i," bars of health.")
def death(n):
    if n==[]:
        global location
        player_choice=input("After your many trials, you finally succumb to your wounds. Your adventure is over. ")
        room1.location='death'
    return player_choice
def item_check(n): #Use player_choice for n.
    if len((n).split())==2:
        coin_count_one=0
        action=(n).split()[0]
        item=(n).split()[1]
        print(" ")
        if action in ['check','open','examine']:
            if item in('coins','torch','note') or item in (inventory):
                if item=='lockbox':
                    if 'note 2' not in (inventory):
                        print("The box is closed and locked.")
                    if 'note 2' in (inventory):
                        print("It's an emptied lockbox.")
                if item=='jewel':
                    print("It's shiny.")
                if item=='box':
                    if 'note' not in (inventory):
                        print(fileroutes.check_box)
                        inventory.append('note')
                        while coin_count_one<=4:
                            coin_count_one+=1
                            inventory.append('coin')
                    if 'note 2' not in (inventory):
                        if 'lockbox' in (inventory):
                            print("It's locked.")
                if item in ['coin','coins']:
                    print("They are old-looking gold coins.")
                if item=='dagger':
                    print("It's not very sharp, but it's better than nothing.")
                if item=='note':
                    if 'note' in (inventory) and 'note 2' not in (inventory):
                        print(fileroutes.check_note)
                    if 'note 2' in (inventory) and 'note' in (inventory):
                        try:
                            note=int(input("Which note do you mean, note 1 or note 2?"))
                            print(" ")
                            if note==1:
                                print(fileroutes.check_note)
                            if note==2:
                                print(fileroutes.check_note_two)
                        except ValueError:
                            print("You'll have to use a number.")
                    if 'note 2' in (inventory) and 'note' not in (inventory):
                        print(fileroutes.check_note_two)
                if item=='sword':
                    print("The sword looks rather intimidating.")
                if item=='paperclip':
                    print("It looks like a normal paperclip.")
                if item=='key':
                    if 'brass key' not in (inventory):
                        print("It's a rusty old key.")
                    if 'brass key' in (inventory):
                        try:
                            key=str.lower(input("Which key do you mean, the rusty key or the brass key?"))
                            print(" ")
                            if 'rusty' in key.split():
                                print("It's a rusty old key.")
                            if 'brass' in key.split():
                                print("It's a worn but well-made brass key.")
                        except ValueError:
                            print("I don't understand which key you wanted to look at.")
                if item=='lighter':
                    print("It's a beat-up bic lighter. Wait... what time period does this game take place in?")
                if item=='torch':
                    if 'torch(unlit)' in (inventory):
                        print("You have an unlit torch.")
                    if 'torch(lit)' in (inventory):
                        print("You have a lit torch.")
        if action in ['light','use']:
            if item in ['torch','lighter']:
                if 'torch(unlit)' in (inventory):
                    print("You light your torch.")
                    inventory.remove('torch(unlit)')
                    inventory.append('torch(lit)')
                elif 'torch(lit)' in (inventory):
                    print("The torch is already lit.")
            if item=='key':
                if 'lockbox' in (inventory) and 'note 2' not in (inventory):
                    inventory.remove('lockbox')
                    inventory.append('jewel')
                    inventory.append('note 2')
                    inventory.append('potion')
                    print(fileroutes.lockbox)
def dice_game(a,b,c,d,e,f):
    gamble=0
    if first_dice==[]:
        first_dice.append('check')
        print(fileroutes.dice_explain)
        print(" ")
    print("You currently have ",inventory.count('coin')," coins to play with.")
    print(" ")
    while gamble==0:
        try:
            gamble+=int(input("How many coins would you like to bet?: "))
        except ValueError:
            print("Use a number, please.")
        print(" ")
    if gamble>inventory.count('coin'):
        print("You don't have that much to gamble with!")
        dice_game(1,2,3,4,5,6)
    onecount_player=0
    twocount_player=0
    threecount_player=0
    fourcount_player=0
    fivecount_player=0
    sixcount_player=0
    onecount_guard=0
    twocount_guard=0
    threecount_guard=0
    fourcount_guard=0
    fivecount_guard=0
    sixcount_guard=0
    rolls_player=random.choices((a,b,c,d,e,f),k=5)
    rolls_guard=random.choices((a,b,c,d,e,f),k=5)
    for i in rolls_player:
        if i==1:
            onecount_player+=1
        if i==2:
            twocount_player+=1
        if i==3:
            threecount_player+=1
        if i==4:
            fourcount_player+=1
        if i==5:
            fivecount_player+=1
        if i==6:
            sixcount_player+=1
    for i in rolls_guard:
        if i==1:
            onecount_guard+=1
        if i==2:
            twocount_guard+=1
        if i==3:
            threecount_guard+=1
        if i==4:
            fourcount_guard+=1
        if i==5:
            fivecount_guard+=1
        if i==6:
            sixcount_guard+=1
    player_score=(onecount_player)+(2**twocount_player)+(3**threecount_player)+(4**fourcount_player)+(5**fivecount_player)+(6**sixcount_player)
    guard_score=(onecount_guard)+(2**twocount_guard)+(3**threecount_guard)+(4**fourcount_guard)+(5**fivecount_guard)+(6**sixcount_guard)
    print("The man rolls ",onecount_guard," one(s), ",twocount_guard," two(s), ",threecount_guard," three(s), ",fourcount_guard," four(s), ",fivecount_guard," five(s), and ",sixcount_guard," six(es).")
    print("His score is ",guard_score,".")
    print(" ")
    print("You roll ",onecount_player," one(s), ",twocount_player," two(s), ",threecount_player," three(s), ",fourcount_player," four(s), ",fivecount_player," five(s), and ",sixcount_player," six(es).")
    print("Your score is ",player_score,".")
    print(" ")
    if player_score==guard_score:
        print("'Ha!', the man exclaims, 'We tied! Guess we've got to try again'. He then starts shaking his dice again.")
    if player_score>guard_score:
        dice.append('win')
        while gamble>0:
            gamble-=1
            inventory.append('coin')
        print("The man looks solemnly at the table and sighs. 'I suppose you beat me', he says as he hands over your loot.")
        if len(dice)>=3:
            print("The man shakes his head slowly. 'No one wins this much', he says. 'Not unless they're cheating'.")
            guard.append('attack')
    if player_score<guard_score:
        while gamble>0:
            gamble-=1
            inventory.remove('coin')
        print("'Ha!', the man exclaims, 'I'm the best at this game!' You dejectedly hand over his winnings.")
    if len(dice)<3 and inventory.count('coin')>=1:
        choice=str.lower(input("Would you like to play again?: "))
        if choice in ['y','yes']:
            dice_game(1,2,3,4,5,6)
def random_descrip(a,b):
    num=random.choice(range(a,b))
    if num in (10,20,30,40,50):
        print(" ")
        if num==10:
            print(fileroutes.random_descrip1)
        if num==20:
            print(fileroutes.random_descrip2)
        if num==30:
            print(fileroutes.random_descrip3)
        if num==40:
            print(fileroutes.random_descrip4)
        if num==50:
            print(fileroutes.random_descrip5)
        
    
    
