import functions
import fileroutes
import random
from random import shuffle
inventory=functions.inventory
health=[1,2,3,4,5]
jewels=[]
door_open_1=[]
items_1=['bed','window','pants','pocket','pockets','door','box','floor','north','south','west','east']
location='room 1'
def vial(n):
    if 'vial' in (n):
        if 'vial' in (inventory):
            print(" ")
            if 'check' in (n) or 'examine' in (n):
                print("It's a vial full of a clear liquid that looks almost... shiny.")
            else:
                inventory.remove('vial')
                health.append(max(health)+1)
                health.append(max(health)+1)
                print("You drink the liquid in the vial and feel strangely rejuvenated. This feeling... it fills you with determination!")
def potion(n):
    if 'potion' in (n):
        if 'potion' in (inventory):
            print(" ")
            if 'check' in (n) or 'examine' in (n):
                print("The potion is grey and murky, and appears to swirl around on its own.")
            else:
                inventory.remove('potion')
                chance=[1,2,3,4,5,6,7,8,9,10]
                random.shuffle(chance)
                if chance[0]<=5:
                    functions.take_damage(health)
                    print("The substance is viscous and nauseating going down. It feels cold and heavy in your stomach. You think you might vomit.")
                if chance[0]>=6:
                    health.append(max(health)+1)
                    print("The substance is viscous and nauseating going down, but it fills your stomach with a welcome warmth. This feeling... it fills you with determination.")
def room_1(n):
    if n=='room 1':
        global location
        note_check=0 
        jewel_check=0
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        vial(player_choice.split())
        functions.item_check(player_choice)
        potion(player_choice.split())
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if action=='look':
                print(fileroutes.start_look_around_text)
            if item in items_1+inventory:
                if action=='examine' or action=='check':
                    if item=='bed':
                        if 'box' not in (inventory):
                            print(fileroutes.check_bed_text)
                        elif 'box' in (inventory):
                            print("There is nothing left under the bed.")
                    if item=='window':
                        print(fileroutes.check_window)
                    if item in ['pants','pocket','pockets']:
                        if 'lighter' not in (inventory):
                            inventory.append('lighter')
                            inventory.append('paperclip')
                            inventory.append('key')
                            items_1.remove('pants')
                            items_1.remove('pocket')
                            items_1.remove('pockets')
                            print(fileroutes.check_pants.read())
                        elif 'lighter' in (inventory):
                            print("You already checked your pants.")
                    if item=='shirt':
                        print("Unlike your pants, it contains nothing of significance.")
                    if item=='door':
                        if 'open' not in (door_open_1):
                            print(fileroutes.check_door)
                        elif 'open' in (door_open_1):
                            print("The door opens to the north.")
                    if item=='box':
                        if 'box' not in (inventory):
                            print("You need to take the box if you want to examine it.")
                    if item=='floor':
                        if 'floor' in (items_1):
                            health.remove(max(health))
                            items_1.remove('floor')
                            items_1.append('jewel')
                            print("You pace the floor for a bit, thinking about your situation, when you suddenly cut your foot on something sharp. Looking down, you see a beautiful red jewel.")
                if action=='take' or action=='grab':
                    if item=='jewel' or item=='gem':
                        if 'jewel' in items_1:
                            inventory.append('jewel')
                            items_1.remove('jewel')
                            jewels.append('red')
                            print("Taken.")
                    if item=='box':
                        if 'box' not in (inventory):
                            inventory.append('box')
                            print("Taken.")
                if action=='open' or action=='use' or action=='unlock':
                    if item=='box':
                        if 'box' not in (inventory):
                            print("You need to take the box before you can open it.")
                    if item=='door':
                        if 'open' not in (door_open_1):
                            if 'paperclip' in (inventory):
                                door_open_1.append('open')
                                inventory.remove('paperclip')
                                print("The key doesn't work but you pick the lock with your paperclip, breaking it in the process. The north door opens.")
                            elif 'paperclip' not in (inventory):
                                print(fileroutes.check_door)
                        elif 'open' in (door_open_1):
                            print("You see a dimly lit hall to the north.")
                    if item=='window':
                        print("It's too high to climb out of.")
                    if item=='bed':
                        print("Now is no time for sleeping!")
                    if item=='paperclip':
                        if 'open' not in (door_open_1):
                            if 'paperclip' in (inventory):
                                door_open_1.append('open')
                                inventory.remove('paperclip')
                                print("You pick the lock with your paperclip. The door opens to the north.")
                    if item=='lighter':
                        print("The room is a bit brighter.")
                    if item=='note':
                        print(fileroutes.check_note)
                    if item=='key':
                        if 'key' in (inventory):
                            print("It doesn't fit the lock.")
                if action=='hit' or action=='break' or action=='punch' or action=='attack':
                    health.remove(max(health))
                    print("You punch it and hurt your hand.")
                if action=='light':
                    if item=='lighter':
                        if 'lighter' in (inventory):
                            print("The room is a bit brighter.")
                if action in ['go','move','walk']:
                        if item=='north':
                            if 'open' in (door_open_1):
                                location='hall choice'
                                print(fileroutes.hallway)
                            elif 'open' not in (door_open_1):
                                print("The door is closed.")
                        elif item!='north':
                            print("You cannot go that way.")
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                print(fileroutes.start_look_around_text)
            if player_choice=='north':
                if 'open' in (door_open_1):
                    location='hall choice'
                    print(fileroutes.hallway)
                if 'open' not in (door_open_1):
                    print("The door is closed.")
        if player_choice.count(' ')>1:
            action=""
            item=""
    return player_choice, action or None, item or None
