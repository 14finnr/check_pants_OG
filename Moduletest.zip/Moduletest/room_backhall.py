#Basics of this room are done. Currently working on guard conversation.
import fileroutes
import functions
import room1
location=room1.location
inventory=functions.inventory
jewels=room1.jewels
health=room1.health
talked=[]
man=[]
items_backhall=['man','guard','guy','ceiling','wall','walls','floor','jewel','east','west','south','north']
def man_fight(n):
    man.append('KO')
    if 'sword' in (n):
        functions.take_damage(health)
        functions.take_damage(health)
        print("You draw your sword and stand in front of the man expectantly.")
        print(fileroutes.big_man_fight)
        print(" ")
        print("Though the man is a fearsome opponent, he doesn't have a sword to match yours. You defeat him without getting too hurt.")
    if 'dagger' in (n) and 'sword' not in (n):
        for i in range(1,4):
            functions.take_damage(health)
        print("You unsheath your dagger and stand in front of the man expectantly.")
        print(fileroutes.big_man_fight)
        print(" ")
        print("Though the man is a fearsome opponent, he doesn't have a dagger to match yours. You defeat him, but are quite injured during the fight.")
    if 'dagger' not in (n) and 'sword' not in (n):
        for i in range(1,6):
            functions.take_damage(health)
        print("You punch the man in the stomach and it hurts your hand.")
        print(fileroutes.big_man_fight)
        print(" ")
        print("The man tosses you around like a ragdoll, but you manage to kick him in the crotch before he kills you. He keels over. You won, but you have been physically broken.")
def backhall(n):
    if n=='back hall':
        global location
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')>1:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if 'look' in player_choice.split():
                if man==[]:
                    print(fileroutes.backhall_w_man)
                if man!=[]:
                    print(fileroutes.backhall_noman)
            if item in (items_backhall+inventory):
                if action in ('go','move','walk'):
                    if item=='west':
                        if man==[]:
                            print("There is a large man blocking your path.")
                        if man!=[]:
                            room1.location='exit choice'
                            print(fileroutes.exit_choice)
                    if item=='east':
                        room1.location='guard post'
                        print("You step back into the small room.")
                if action in ('check','examine'):
                    if item in ('wall','walls'):
                        print("The walls are bare concrete.")
                    if item=='ceiling':
                        if 'jewel' in (items_backhall):
                            print("Looking up at the ceiling, you can see an orange jewel embedded in the concrete.")
                        if 'jewel' not in (items_backhall):
                            print("You look up and see the hole where you knocked the jewel loose.")
                    if item in ('man','guard','guy'):
                        if man==[]:
                            print("He is a comically large man standing in front of a set of stairs with his arms crossed. He stands still as a statue, and is unperturbed by your presence.")
                        if man!=[]:
                            print("You search the unconscious man. He has no personal effects, and his pants don't even seem to have pockets. Strange.")
                    if item in ('floor','floors'):
                        print("The floor is stark and bare.")
                if action in ('take','grab'):
                    if item=='jewel' and 'jewel' in (items_backhall):
                        if 'sword' not in (inventory):
                            print("You jump up and try to knock the jewel loose, but you cannot reach it.")
                        if 'sword' in (inventory):
                            items_backhall.remove('jewel')
                            inventory.append('jewel')
                            print("Using your sword, you manage to just barely knock the jewel loose. It falls right into your hand.")
                if action in ('speak','talk'):
                    if item in ('man','guard','guy'):
                        if man==[]:
                            if 'uniform' not in (inventory):
                                if talked!=[]:
                                    print('"Where are we?", you ask. "Who are you?" He just shakes his head and says, "I have no answers for you, pal."')
                                if talked==[]:
                                    talked.append('talked')
                                    print(fileroutes.man_firsttalk)               
                                pay_toll=str.lower(input("Will you pay the toll?(yes/no): "))
                                print(" ")
                                if pay_toll in ('yes','y'):
                                    if inventory.count('coin')<15:
                                        print("You don't have enough money.")
                                    if inventory.count('coin')>=15:
                                        leave=str.lower(input("The man looks at your money and says 'Once you've paid me, I won't let you come back. Are you sure you're ready to go?'(yes/no): "))
                                        print(" ")
                                        if leave in ('yes','y'):
                                            for i in range(1,16):
                                                inventory.remove('coin')
                                            room1.location='exit choice'
                                            print("You pay the man and he steps aside. You climb up the stairs.")
                                            print(fileroutes.exit_choice)
                                        if leave in ('no','n'):
                                            print("You decide not to leave just yet.")
                                if pay_toll in ('no','n'):
                                    print("You decide not to leave just yet.")
                            if 'uniform' in (inventory):
                                if talked!=[]:
                                    leave=str.lower(input('"Are you ready to leave?" the man asks. Will you leave?(yes/no): '))
                                if talked==[]:
                                    talked.append('yes')
                                    leave=str.lower(input(fileroutes.man_talk_uniform))
                                print(" ")
                                if leave in ('y','yes'):
                                    room1.location='exit choice'
                                    print("The man steps aside and you walk up the stairs.")
                                    print(fileroutes.exit_choice)
                                if leave in ('n','no'):
                                    print("You decide not to leave just yet.")
                        if man!=[]:
                            print("He isn't in any condition to talk.")
                if action in ('hit','attack','punch','fight','kill'):
                    if item in ('man','guard','guy'):
                        man_fight(inventory)
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                if man==[]:
                    print(fileroutes.backhall_w_man)
                if man!=[]:
                    print(fileroutes.backhall_noman)
            if player_choice=='east':
                room1.location='guard post'
                print("You step back into the small room.")
            if player_choice=='west':
                if man==[]:
                    print("There is a large man blocking your path.")
                if man!=[]:
                    room1.location='exit choice'
                    print(fileroutes.exit_choice)
            if player_choice in ('speak','talk'):
                if man==[]:
                    print("You'll have to specify what you want to ",player_choice," to.")
                if man!=[]:
                    print("The man is in no state to have a discussion.")
    return player_choice, action or None, item or None
