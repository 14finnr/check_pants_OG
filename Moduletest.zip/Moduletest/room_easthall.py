import room1
import functions
import fileroutes
location=room1.location
inventory=functions.inventory
jewels=room1.jewels
health=room1.health
monster=[]
torch=[]
door_open_easthall=[]
items_monster=['monster','torch','north','south','west','east']
items_easthall=['torch','door','alcove','north','south','west','east']
def east_hall(n):
    if n=='east hall':
        global location
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        if monster!=[]:
            functions.item_check(player_choice)
        print(" ")
        if monster==[]:
            if player_choice.count(' ')==1 and len(player_choice.split())!=2:
                action=""
                item=""
            if player_choice.count(' ')==1 and len(player_choice.split())==2:
                action=player_choice.split()[0]
                item=player_choice.split()[1]
                if action=='look':
                    print("In front of you is a great hairy monster. Beside him on one side is an unlit torch, and on the other, to his east, a dark alcove in a broken wall.")
                if item=='torch' or item in (items_monster+inventory):
                    if action in ['take','grab']:
                        #The Jacob rule
                        if item=='torch' and 'torch' in (items_easthall):
                            items_easthall.remove('torch')
                            if torch==[]:
                                inventory.append('torch(unlit)')
                            if torch!=[]:
                                inventory.append('torch(lit)')
                            print("Taken.")
                    #Added this for you, Shaun. <3
                    if action in ['fuck','bang']:
                        if item=='monster':
                            monster.append('gone')
                            fuck_choice=str.lower(input(fileroutes.fuck_monster))
                            if fuck_choice in ['t','top']:
                                functions.take_damage(health)
                                functions.take_damage(health)
                                functions.take_damage(health)
                                functions.take_damage(health)
                                inventory.clear()
                                inventory.append('lighter')
                                print("You immediately know that you've fucked up. This beautiful beast is not one to be mounted. It mauls the shit out of you.")
                                print("When you wake up the beast is gone, along with all of your clothes. To your relief, you find that it left behind the lighter, which you take.")
                            if fuck_choice in ['b','bottom']:
                                functions.take_damage(health)
                                inventory.append('coin')
                                inventory.append('coin')
                                inventory.append('coin')
                                print("You're very brave. The beast is hung like several horses, but you take it like a man while he shreds your bum to pieces.")
                                print("When it finishes, it throws several coins on the ground and then walks away. You take them like the bitch you are.")
                            if fuck_choice not in ['t','b','top','bottom']:
                                functions.take_damage(health)
                                inventory.append('coin')
                                inventory.append('coin')
                                inventory.append('coin')
                                print("You can't decide, so the monster decides for you. The beast is hung like several horses, but you take it like a man while it shreds your bum to pieces.")
                                print("When it finishes, it throws several coins on the ground and then walks away. You take them like the bitch you are.")
                    if action in ['hit','punch','attack']:
                        if item=='monster':
                            monster.append('gone')
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print(fileroutes.sad_hit)
                    if action in ['go','walk','move']:
                        if item=='east':
                            monster.append('gone')
                            functions.take_damage(health)
                            print("You run into the alcove, escaping the monster but slipping and hurting yourself in the process.")
                            print("It pokes its head in, looking for you for a moment, before eventually plodding off. With the beast gone, you re-enter the room.")
                            if 'torch(lit)' or 'torch(unlit)' in (inventory):
                                print("You are in a barely-lit room. It has an empty torch sconce on one side, a dark alcove to the east, and a door to the north.")
                            if 'torch(lit)' not in (inventory) and 'torch(unlit)' not in (inventory):
                                if torch==[]:
                                    print("You are in a barely-lit room. It has an unlit torch on one side, a dark alcove to the east, and a door to the north.")
                                elif 'lit' in (torch):
                                    print("You are in a barely-lit room. It has a lit torch on one side, a dark alcove to the east, and a door to the north.")
                        if item in ['back','west']:
                            print("You can't turn back right now. You have to act!")
                    if action=='light':
                        if item in ['torch','lighter']:
                            monster.append('gone')
                            torch.append('lit')
                            functions.take_damage(health)
                            print("You quickly light the torch and shove it in the beast's face.")
                            print(fileroutes.sad_hit)
                            if 'torch(unlit)' in (inventory):
                                inventory.remove('torch(unlit)')
                                inventory.append('torch(lit)')
                            if 'torch(unlit)' not in (inventory) and 'torch(lit)' not in (inventory):
                                items_easthall.remove('torch')
                                inventory.append('torch(lit)')
                                print("You take the lit torch.")
                    if action=='use':
                        if item=='torch':
                            monster.append('gone')
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print("You grab the torch and shove it in the beast's face, but it's somewhat underwhelming without any fire.")
                            print(fileroutes.sad_hit)
                            if 'torch(unlit)' not in (inventory) and 'torch(lit)' not in (inventory):
                                inventory.append('torch(unlit)')
                                items_easthall.remove('torch')
                                print("You take the unlit torch.")
                        if item in (inventory):
                            if item=='lighter':
                                monster.append('gone')
                                torch.append('lit')
                                functions.take_damage(health)
                                print("You quickly light the torch and shove it in the beast's face.")
                                print(fileroutes.sad_hit)
                                if 'torch(unlit)' in (inventory):
                                    inventory.remove('torch(unlit)')
                                    inventory.append('torch(lit)')
                                if 'torch' not in (inventory):
                                    items_easthall.remove('torch')
                                    inventory.append('torch(lit)')
                                    print("You take the torch.")
                            if item in ['knife','dagger']:
                                monster.append['gone']
                                functions.take_damage(health)
                                inventory.remove('dagger')
                                print("You swing your dagger at the beast, wounding it. It swipes it out of your hands and breaks it.")
                                print(fileroutes.sad_hit)
                        if item=='monster':
                            monster.append('gone')
                            functions.take_damage(health)
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print("Whatever it is you just tried to do, it didn't go very well.")
                            print(fileroutes.normal_hit)
                    if action=='hug':
                        if item=='monster':
                            monster.append('gone')
                            print(fileroutes.hug_monster)
                    if action in ['speak','talk']:
                        monster.append('gone')
                        print(fileroutes.monster_jewel)
                        if 'jewel' in (inventory):
                            give_jewel=str.lower(input("Would you like to give it the jewel in your pocket?: "))
                            if give_jewel in ['y','yes']:
                                jewels.pop(0)
                                inventory.remove('jewel')
                                inventory.append('vial')
                                print(fileroutes.give_gem)
                            if give_jewel in ['n','no']:
                                jewels.pop(0)
                                inventory.remove('jewel')
                                functions.take_damage(health)
                                functions.take_damage(health)
                                print(fileroutes.deny_jewel)
                            if give_jewel not in ['y','n','yes','no']:
                                functions.take_damage(health)
                                functions.take_damage(health)
                                functions.take_damage(health)
                                print("In the heat of the moment you can only think nonsensical gibberish.")
                                print(fileroutes.normal_hit)
                        elif 'jewel' not in (inventory):
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print("You don't know anything about any jewel. While you're trying to think of a response it abruptly howls, 'You no have jewel!!'")
                            print(fileroutes.normal_hit)
                        print(" ")
                    if action in ['check','examine']:
                        if item=='monster':
                            monster.append('gone')
                            functions.take_damage(health)
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print("You awkwardly approach the beast to get a better look. It seems to get aggravated at this.")
                            print(fileroutes.normal_hit)
                        elif item!='monster':
                            print("You don't have time to look around!")
            if player_choice.count(' ')==0:
                action=""
                item=""
                if player_choice=='look':
                    print("In front of you is a great hairy monster. Beside him on one side is an unlit torch, and on the other, to his east, a dark alcove in a broken wall.")
                if player_choice in ['back','west']:
                    print("You can't turn back right now. You have to act!")
                if player_choice=='east':
                    monster.append('gone')
                    functions.take_damage(health)
                    print("You run into the alcove, escaping the monster but slipping and hurting yourself in the process.")
                    print("It pokes its head in, looking for you for a moment, before eventually plodding off. With the beast gone, you re-enter the room.")
                    if 'torch(lit)' in (inventory) or 'torch(unlit)' in (inventory):
                        print("You are in a barely-lit room. It has an empty torch sconce on one side, a dark alcove to the east, and a door to the north.")
                    if 'torch(unlit)' not in (inventory):
                        if torch==[]:
                            print("You are in a barely-lit room. It has an unlit torch on one side, a dark alcove to the east, and a door to the north.")
                        elif 'lit' in (torch):
                            print("You are in a barely-lit room. It has a lit torch on one side, a dark alcove to the east, and a door to the north.")        
            if player_choice.count(' ')>1:
                action=""
                item=""
        elif 'gone' in (monster):
            if player_choice.count(' ')==1 and len(player_choice.split())!=2:
                action=""
                item=""
            if player_choice.count(' ')==1 and len(player_choice.split())==2:
                action=player_choice.split()[0]
                item=player_choice.split()[1]
                if action=='look':
                    if 'lit' in (torch):
                        if 'torch' in (items_easthall):
                            print("You are in a small room with a lit torch, an alcove to the east, and a door to the north.")
                        elif 'torch' not in (items_easthall):
                            print("You are in a small room with an empty torch sconce, an alcove to the east, and a door to the north.")
                    elif torch==[]:
                        if 'torch' in (items_easthall):
                            print("You are in a small room with an unlit torch, an alcove to the east, and a door to the north.")
                        elif 'torch' not in (items_easthall):
                            print("You are in a small room with an empty torch sconce, an alcove to the east, and a door to the north.")
                if item in (items_easthall+inventory):
                    if action in ['use','open','knock','unlock']:
                        if item=='key':
                            if 'open' in (door_open_easthall):
                                print("The door is already open.")
                            if 'open' not in (door_open_easthall):
                                print("The key doesn't fit the lock.")
                        if item=='door':
                            if 'open' not in (door_open_easthall):
                                room1.location='guard post'
                                door_open_easthall.append('open')
                                print("After trying your key (unsuccessfully), you knock on the door. To your great surprise, it swings open.")
                                print(fileroutes.guard_convo_1)
                                print("You step into the north room.")
                            elif 'open' in (door_open_easthall):
                                print("The door is already open.")
                        if action=='use':
                            if item=='lighter':
                                if torch==[]:
                                    torch.append('lit')
                                    print("You light the torch.")
                                    if 'torch(unlit)' in (inventory):
                                        inventory.remove('torch(unlit)')
                                        inventory.append('torch(lit)')
                                elif 'lit' in (torch):
                                    print("The torch is already lit.")
                    if action=='light':
                        if item in ('lighter','torch'):
                            if torch==[]:
                                torch.append('lit')
                                if 'torch(unlit)' not in (inventory) and 'torch(lit)' not in (inventory):
                                    print("You light the torch.")
                                if 'torch(unlit)' in (inventory):
                                    inventory.remove('torch(unlit)')
                                    inventory.append('torch(lit)')
                            elif 'lit' in (torch):
                                print("The torch is already lit.")
                    if action=='take':
                        if item=='torch':
                            if 'torch' in (items_easthall):
                                items_easthall.remove('torch')
                                if torch==[]:
                                    inventory.append('torch(unlit)')
                                if torch!=[]:
                                    inventory.append('torch(lit)')
                                print("Taken.")
                        if item=='sword':
                            if 'sword' in (items_easthall):
                                items_easthall.remove('sword')
                                inventory.append('sword')
                                print("Taken.")
                        if item in ['jewel','gem']:
                            if 'jewel' in (items_easthall):
                                items_easthall.remove('jewel')
                                inventory.append('jewel')
                                print("Taken.")
                    if action in ['check','examine']:
                        if item=='door':
                            if door_open_easthall==[]:
                                print("It appears sturdy.")
                            if 'open' in (door_open_easthall):
                                print("The door is open.")
                        if item=='alcove':
                            if 'torch(lit)' in (inventory):
                                if 'skeleton' not in (items_easthall):
                                    items_easthall.append('skeleton')
                                if 'sword' not in (items_easthall) and 'sword' not in (inventory):
                                    items_easthall.append('sword')
                                if 'sword' not in (inventory):
                                    print("Using your torch to peer into the alcove, you see a skeleton on the ground with a sword laying next to it.")
                                if 'sword' in (inventory):
                                    print("Using your torch to peer into the alcove, you see a skeleton on the ground.")
                            if 'torch(lit)' not in (inventory):
                                print("You peer into the alcove, but it's too dark to see very well.")
                        if item=='skeleton':
                            items_easthall.remove('skeleton')
                            items_easthall.append('jewel')
                            print("You spy something shining in the skeleton's ribcage. Looking more closely, you see that it is a green jewel. The poor bastard must have swallowed it.")
                    if action in ['hit','attack','punch']:
                        functions.take_damage(health)
                        print("You punch it and hurt your hand.")
                    if action in ['go','move','walk']:
                        if item=='north':
                            if door_open_easthall==[]:
                                print("The door is closed.")
                            elif 'open' in door_open_easthall:
                                room1.location='guard post'
                                print("You step into the north room.")
                        if item in ['west','back']:
                            room1.location='hall choice'
                            print("You go back the way you came.")
                            print(fileroutes.hallway)
                        if item=='east':
                            if 'torch(lit)' in (inventory):
                                print("You confidently enter the alcove with torch in hand.")
                            if 'torch(lit)' not in (inventory):
                                functions.take_damage(health)
                                print("You shakily stumble down the passage in the darkness, falling once and twisting your ankle.")
                            sewer_enter=str.lower(input(fileroutes.alcove))
                            if sewer_enter in ['y','yes']:
                                room1.location='sewer'
                                print("You follow the stairs carefully.")
                                print(fileroutes.sewer_go)
                            if sewer_enter not in ['y','yes']:
                                print("You return to the room.")
            if player_choice.count(' ')==0:
                action=""
                item=""
                if player_choice=='look':
                    if 'lit' in (torch):
                        if 'torch' in (items_easthall):
                            print("You are in a small room with a lit torch, an alcove to the east, and a door to the north.")
                        elif 'torch' not in (items_easthall):
                            print("You are in a small room with an empty torch sconce, an alcove to the east, and a door to the north.")
                    elif torch==[]:
                        if 'torch' in (items_easthall):
                            print("You are in a small room with an unlit torch, an alcove to the east, and a door to the north.")
                        elif 'torch' not in (items_easthall):
                            print("You are in a small room with an empty torch sconce, an alcove to the east, and a door to the north.")
                if player_choice=='north':
                    if 'open' in (door_open_easthall):
                        room1.location='guard post'
                        if door_open_easthall==[]:
                                print("The door is closed.")
                        if 'open' in door_open_easthall:
                            room1.location='guard post'
                            print("You step into the north room.")
                    if 'open' not in (door_open_easthall):
                        print("The door is closed.")
                if player_choice in ['west','back']:
                    room1.location='hall choice'
                    print(fileroutes.hallway)
                if player_choice=='east':
                    if 'torch(lit)' in (inventory):
                        print("You confidently enter the alcove with torch in hand.")
                    if 'torch(lit)' not in (inventory):
                        functions.take_damage(health)
                        print("You shakily stumble down the passage in the darkness, falling once and twisting your ankle.")
                    sewer_enter=str.lower(input(fileroutes.alcove))
                    if sewer_enter in ['y','yes']:
                        room1.location='sewer'
                        print("You follow the stairs carefully.")
                        print(fileroutes.sewer_go)
                    if sewer_enter not in ['y','yes']:
                        print("You return to the room.")
            if player_choice.count(' ')>1:
                action=""
                item=""
    return player_choice, action or None, item or None
