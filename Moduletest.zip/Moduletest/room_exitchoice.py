import fileroutes
import functions
import room1
import room_backhall
import room_statue
location=room1.location
inventory=functions.inventory
jewels=room1.jewels
health=room1.health
man=room_backhall.man
def exitchoice(n):
    if n=='exit choice':
        global location
        player_choice=str.lower(input("Which way would you like to go?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')>1:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if 'look' in player_choice.split():
                print(fileroutes.exit_choice)
            if action in ('go','move','walk'):
                if item=='east':
                    if man==[]:
                        print("You know that the mysterious guard won't let you back down. It's probably a bad idea.")
                    if man!=[]:
                        room1.location='back hall'
                        print("You descend the stairs and enter the room you came from.")
                if item=='north':
                    room1.location='valley'
                if item=='south':
                    room1.location='statue'
                    print(fileroutes.south_exit)
                    if len(room_statue.eyes)==1:
                        print("The statue's left eye has a beautiful jewel in it.")
                    if len(room_statue.eyes)==2:
                        print("Two of the statue's eyes have beautiful jewels in them.")
                    if len(room_statue.eyes)==3:
                        print("The three jeweled eyes of the statue glow with a fiery energy.")
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                print(fileroutes.exit_choice)
            if player_choice=='east':
                if man==[]:
                    print("You know that the mysterious guard won't let you back down. It's probably a bad idea.")
                if man!=[]:
                    room1.location='back hall'
                    print("You descend the stairs and enter the room you came from.")
            if player_choice=='north':
                room1.location='valley'
            if player_choice=='south':
                room1.location='statue'
                print(fileroutes.south_exit)
                if len(room_statue.eyes)==1:
                    print("The statue's left eye has a beautiful jewel in it.")
                if len(room_statue.eyes)==2:
                    print("Two of the statue's eyes have beautiful jewels in them.")
                if len(room_statue.eyes)==3:
                    print("The three jeweled eyes of the statue glow with a fiery energy.")
    return player_choice, action or None, item or None
