import fileroutes
import functions
import room1
import room_easthall
import room_backhall
location=room1.location
inventory=functions.inventory
health=room1.health
jewels=room1.jewels
guard=functions.guard
table=[]
jewel_find=[]
door_open_easthall=room_easthall.door_open_easthall
items_guardroom=['fire','fireplace','guard','man','guy','hall','door','table','apple','stream','river','water','dice','game','north','south','east','west']
def guard_attacks(n):
    if 'attack' in (n) and 'KO' not in (guard):
        guard.append('KO')
        print(fileroutes.guard_attack)
        if 'sword' in (inventory):
            functions.take_damage(health)
            print("He is a scary adversary, but a dagger is no match for a sword. He barely hurts you at all before you defeat him.")
        if 'sword' not in (inventory) and 'dagger' not in (inventory):
            functions.take_damage(health)
            functions.take_damage(health)
            functions.take_damage(health)
            print("You have no weapon to defend yourself with, so he hurts you pretty badly. After a long, brutal fight you manage to knock him out.")
        if 'dagger' in (inventory) and 'sword' not in (inventory):
            functions.take_damage(health)
            functions.take_damage(health)
            print("You pull out your own dagger. You are slightly wounded during the fight, but still manage to defeat him.")
def guard_post(n):
    if n=='guard post':
        global location
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if 'look' in player_choice.split():
                if guard==[]:
                    print(fileroutes.guard_room_guard)
                if guard!=[]:
                    print(fileroutes.guard_room_noguard)
            if item in (items_guardroom+inventory):
                if action in ('go','move','walk'):
                    if item=='west':
                        room1.location='back hall'
                        if room_backhall.man==[]:
                            print(fileroutes.backhall_w_man)
                        if room_backhall.man!=[]:
                            print(fileroutes.backhall_noman)
                    if item=='south':
                        if door_open_easthall==[]:
                            print("The south door is closed.")
                        if door_open_easthall!=[]:
                            room1.location='east hall'
                            if room_easthall.monster==[]:
                                print(fileroutes.monster_encounter)
                            if room_easthall.monster!=[]:
                                if 'torch(lit)' in (inventory) or 'torch(unlit)' in (inventory):
                                    print("You are in a barely-lit room. It has an empty torch sconce on one side, a dark alcove to the east, and a door to the north.")
                                if 'torch' in room_easthall.items_easthall:
                                    if torch==[]:
                                        print("You are in a barely-lit room. It has an unlit torch on one side, a dark alcove to the east, and a door to the north.")
                                    if torch!=[]:
                                        print("You are in a barely-lit room. It has a lit torch on one side, a dark alcove to the east, and a door to the north.")
                if action in ('open','unlock','use'):
                    if item=='door':
                        if door_open_easthall==[]:
                            if guard==[]:
                                room_easthall.door_open_easthall.append('open')
                                print("'You wanna go through there? Here I'll open it for you, but I should mention that you might run into Old Fred. If ya do, don't be scared. Just give him a big old hug and he'll leave ya alone.'")
                                print("The man opens the south door.")
                                if room_easthall.monster==[]:
                                    print("You can see a horrifying monster through the open door.")
                                if room_easthall.monster!=[]:
                                    print("You peer in, and the room looks empty.")
                            elif guard!=[]:
                                if 'brass key' in (inventory):
                                    room_easthall.door_open_easthall.append('open')
                                    print("You open the door with the brass key.")
                                    if room_easthall.monster==[]:
                                        print("You can see a horrifying monster through the open door.")
                                    if room_easthall.monster!=[]:
                                        print("You peer in, and the room looks empty.")
                                if 'brass key' not in (inventory):
                                    print("The key doesn't fit the door's lock.")
                    if item=='key':
                        if door_open_easthall==[]:
                            print("The key doesn't fit the door's lock.")
                        if door_open_easthall!=[]:
                            print("The door is already open.")
                if action in ('talk','speak'):
                    if item in ('guard','man','guy'):
                        if guard==[]:
                            play=str.lower(input(fileroutes.guard_talk))
                            if play in ['y','yes']:
                                if inventory.count('coin')>0:
                                    functions.dice_game(1,2,3,4,5,6)
                                    guard_attacks(guard)
                                if inventory.count('coin')==0:
                                    print("You don't have enough money to play with.")
                            if play not in ['y','yes']:
                                print("He goes back to idly rolling his dice.")
                        if guard!=[]:
                            print("He lays unconscious on the floor.")
                if action=='play':
                    if item in ('dice','game'):
                        if guard==[]:
                            if guard==[]:
                                play=str.lower(input(fileroutes.guard_talk))
                            if play in ['y','yes']:
                                if inventory.count('coin')>0:
                                    functions.dice_game(1,2,3,4,5,6)
                                    guard_attacks(guard)
                                if inventory.count('coin')==0:
                                    print("You don't have enough money to play with.")
                            if play not in ['y','yes']:
                                print("He goes back to idly rolling his dice.")
                        if guard!=[]:
                            print("The man is in no state to play with you.")
                if action in ('check','examine'):
                    if item in ('fire','fireplace'):
                        print("It burns brightly.")
                    if item in ('water','river','stream'):
                        if 'jewel' not in (items_guardroom) and jewel_find==[]:
                            print("Looking into the water, you spy a shiny purple jewel nestled between two rocks.")
                            items_guardroom.append('jewel')
                            jewel_find.append('found')
                        if 'jewel' not in (items_guardroom) and jewel_find!=[]:
                            print("The stream is small but dangerous.")
                    if item in ('guard','man','guy'):
                        if guard==[]:
                            print("He is a large, dirty man with an unkempt beard, and appears to be wearing some sort of uniform.")
                        if guard!=[]:
                            if 'searched' not in (guard):
                                guard.append('searched')
                                items_guardroom.append('coin')
                                items_guardroom.append('coins')
                                items_guardroom.append('uniform')
                                items_guardroom.append('clothes')
                                items_guardroom.append('key')
                                items_guardroom.append('dagger')
                                print("You search the uniformed man. In his pockets are seven gold coins and a bronze key. He is still wearing his uniform and his dagger lies next to him.")
                            if 'searched' in (guard):
                                print("You already checked the guard.")
                    if item=='table':
                        if table==[]:
                            if 'apple' in (items_guardroom):
                                print("On the table is a juicy-looking apple.")
                            if 'apple' not in (items_guardroom):
                                print("The table is bare.")
                        if table!=[]:
                            print("The table is broken.")
                    if item=='door':
                        if room_easthall.door_open_easthall==[]:
                            print("It's a sturdy-looking door leading south. It is currently closed.")
                        if room_easthall.door_open_easthall!=[]:
                            if room_easthall.monster==[]:
                                print("Looking through the south door, you can see a hulking monster standing in the next room.")
                            if room_easthall.monster!=[]:
                                print("Looking through the south door, you see an empty room.")
                if action in ('take','grab'):
                    if item=='jewel':
                        if 'jewel' in (items_guardroom):
                            items_guardroom.remove('jewel')
                            inventory.append('jewel')
                            jewels.append('purple')
                            print('Taken.')
                    if item in ('coin','coins'):
                        if 'coin' in (items_guardroom):
                            items_guardroom.remove('coin')
                            items_guardroom.remove('coins')
                            for i in range(1,8):
                                inventory.append('coin')
                            print("Taken.")
                    if item in ('uniform','clothes'):
                        if 'uniform' in (items_guardroom):
                            items_guardroom.remove('clothes')
                            items_guardroom.remove('uniform')
                            inventory.append('uniform')
                            print("You put on his clothes. They smell like sweat and beer, but it might come in handy to look like a guard.")
                    if item=='dagger':
                        if 'dagger' in (items_guardroom):
                            items_guardroom.remove('dagger')
                            inventory.append('dagger')
                            print('Taken.')
                    if item=='key':
                        if 'key' in (items_guardroom):
                            items_guardroom.remove('key')
                            inventory.append('brass key')
                            print('Taken.')
                    if item=='apple':
                        if 'apple' in (items_guardroom):
                            items_guardroom.remove('apple')
                            inventory.append('apple')
                            print('Taken.')
                if action=='eat':
                    if item=='apple':
                        if 'apple' not in (inventory):
                            print("You need to have an apple before you can eat one.")
                        if 'apple' in (inventory):
                            health.append(max(health)+1)
                            inventory.remove('apple')
                            print("Now that you're eating, you realize how hungry you were. Having a full belly... it fills you with determination.")
                if action in ('hit','break','punch','attack','fight','kill'):
                    if item=='table':
                        if table==[]:
                            if 'sword' in (inventory):
                                table.append('broken')
                                print("You bring your sword crashing down on the center of the table, splitting it in half.")
                                functions.guard.append('attack')
                                guard_attacks(guard)
                    if item in ('guard','man','guy'):
                        if guard==[]:
                            print("You take a random swing at him, but he's more aware than he seems. He deftly dodges your attack.")
                            functions.guard.append('attack')
                            guard_attacks(guard)
                    if item in ('fire','fireplace'):
                        print("It burns you.")
                        functions.take_damage(health)
                        functions.take_damage(health)
                    if item not in ('guard','man','guy','table','fire','fireplace'):
                        functions.take_damage(health)
                        print("You hit it and hurt your hand.")
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                if guard==[]:
                    print(fileroutes.guard_room_guard)
                if 'KO' in (guard):
                    print(fileroutes.guard_room_noguard)
            if player_choice=='west':
                room1.location='back hall'
                if room_backhall.man==[]:
                    print(fileroutes.backhall_w_man)
                if room_backhall.man!=[]:
                    print(fileroutes.backhall_noman)
            if player_choice=='south':
                if room_easthall.door_open_easthall==[]:
                    print("The south door is closed.")
                if 'open' in (room_easthall.door_open_easthall):
                    room1.location='east hall'
                    if room_easthall.monster==[]:
                        print(fileroutes.monster_encounter)
                    if room_easthall.monster!=[]:
                        if 'torch(lit)' in (inventory) or 'torch(unlit)' in (inventory):
                            print("You are in a barely-lit room. It has an empty torch sconce on one side, a dark alcove to the east, and a door to the north.")
                        if 'torch' in room_easthall.items_easthall:
                            if room_easthall.torch==[]:
                                print("You are in a barely-lit room. It has an unlit torch on one side, a dark alcove to the east, and a door to the north.")
                            if room_easthall.torch!=[]:
                                print("You are in a barely-lit room. It has a lit torch on one side, a dark alcove to the east, and a door to the north.")
        if player_choice.count(' ')>1:
            action=""
            item=""
    return player_choice, action or None, item or None
