import functions
import fileroutes
import room_westhall
import room1
import room_easthall
health=room1.health
inventory=functions.inventory
location=room1.location
torch=room_easthall.torch
def hall_choice(n):
    if n=='hall choice':
        global location
        player_choice=str.lower(input("Which way would you like to go?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if action=='look' or item=='look':
                print(fileroutes.hallway)
            if action in ['go','move','walk'] and item in ['s','south']:
                print("You go back into the room.")
                print(fileroutes.start_look_around_text)
                room1.location='room 1'
            if action in ['go','move','walk'] and item in ['w','west']:
                if 'sound' in (room_westhall.items_westhall):
                    print(fileroutes.left_hall)
                if 'sound' not in (room_westhall.items_westhall):
                    print(fileroutes.left_hall_nosound)
                if 'torch(lit)' in (inventory):
                    print("Your torch helps you see that the stairs are to the south and the stream flows to the north.")
                room1.location='west hall'
            if action in ['go','move','walk'] and item in ['e','east']:
                room1.location='east hall'
                if room_easthall.monster==[]:
                    print(fileroutes.right_hall)
                    print(fileroutes.monster_encounter)
                if 'gone' in (room_easthall.monster):
                    if 'lit' in (torch):
                        if 'torch' in (room_easthall.items_easthall):
                            print("You are in a small room with a lit torch, an alcove to the east, and a door to the north.")
                        elif 'torch' not in (room_easthall.items_easthall):
                            print("You are in a small room with an empty torch sconce, an alcove to the east, and a door to the north.")
                    elif torch==[]:
                        if 'torch' in (room_easthall.items_easthall):
                            print("You are in a small room with an unlit torch, an alcove to the east, and a door to the north.")
                        elif 'torch' not in (room_easthall.items_easthall):
                            print("You are in a small room with an empty torch sconce, an alcove to the east, and a door to the north.")
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                print(fileroutes.hallway)
            if player_choice=='back' or player_choice=='south':
                print("You go back into the room.")
                print(fileroutes.start_look_around_text)
                room1.location='room 1'
            if player_choice=='w' or player_choice=='west':
                if 'sound' in (room_westhall.items_westhall):
                    print(fileroutes.left_hall)
                if 'sound' not in (room_westhall.items_westhall):
                    print (fileroutes.left_hall_nosound)
                if 'torch(lit)' in (inventory):
                    print("Your torch helps you see that the stairs are to the south and the stream flows to the north.")
                room1.location='west hall'
            if player_choice in ['e', 'east']:
                room1.location='east hall'
                if room_easthall.monster==[]:
                    print(fileroutes.right_hall)
                    print(fileroutes.monster_encounter)
                if room_easthall.monster!=[]:
                    if 'torch(lit)' in (inventory) or 'torch(unlit)' in (inventory):
                        print("You are in a barely-lit room. It has an empty torch sconce on one side, a dark alcove to the east, and a door to the north.")
                    if room_easthall.torch==[]:
                        if 'torch(lit)' not in (inventory) and 'torch(unlit)' not in (inventory):
                            print("You are in a barely-lit room. It has an unlit torch on one side, a dark alcove to the east, and a door to the north.")
                    if room_easthall.torch!=[]:
                        if 'torch(lit)' not in (inventory) and 'torch(unlit)' not in (inventory):
                            print("You are in a barely-lit room. It has a lit torch on one side, a dark alcove to the east, and a door to the north.")
        if player_choice.count(' ')>1:
            action=""
            item=""
    return player_choice, action or None, item or None
