import room1
import fileroutes
import functions
location=room1.location
health=room1.health
inventory=functions.inventory
def sacrifice(n):
    if n=='sacrifice':
        global location
        print(fileroutes.sacrifice)
        if inventory.count('jewel')==0:
            print("She then steps forward and pushes you off the edge.")
            room1.health.clear()
        if inventory.count('jewel')==1:
            print(fileroutes.sacrifice_ending)
            print("The woman walks up slowly, takes the stone from the ground, and says, 'You are lucky, stranger'. The figures then turn and walk away, back into their home. You are free.")
        if inventory.count('jewel')==2:
            print(fileroutes.sacrifice_ending)
            print("'Oh you like that huh?', you yell. 'Well check this out!', and you pull out another jewel. 'It is a sign', the woman says. 'You are one of us'. She then takes you by the hand and leads you somewhere you do not know, while the others follow.")
        if inventory.count('jewel')>=3:
            print(fileroutes.sacrifice_ending)
            print("'Oh you like that huh?', you yell. 'Well check this out!', and you pull out two more jewels. The crowd gasps. 'You... you are the chosen one', the woman says. She bows before you, as do the rest of the hooded figures. You survey your new flock, and decide that you like this power.")
        print("Your adventure is over.")
        player_choice=input(" ")
        action=""
        item=""
    return player_choice, action or None, item or None
