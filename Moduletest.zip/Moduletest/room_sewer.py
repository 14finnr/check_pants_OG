import fileroutes
import functions
import room1
import room_easthall
location=room1.location
inventory=functions.inventory
jewels=room1.jewels
health=room1.health
items_sewer=['shrine','altar','tunnel','body','corpse','cultist','cultists','figure','figures','north','south','east','west']
def sewer(n):
    if n=='sewer':
        global location
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if action=='look':
                print(fileroutes.sewer_look)
            if item in (items_sewer+inventory):
                if action in ['check','examine']:
                    if item in ['shrine','altar']:
                        print("It appears to be a shrine to a deity that you do not recognize. 'A prayer might be just what I need...' you think to yourself bitterly.")
                    if item in ['cultist','cultists','figure','figures']:
                        print("You are curious about them, but your courage has limits.")
                    if item in ['body','corpse']:
                        if 'lockbox' not in (inventory):
                            items_sewer.append('lockbox')
                            print("The body is fresh. In his hands is a small lockbox.")
                        elif 'lockbox' in (inventory):
                            print("The body is fresh.")
                    if item in ['box','lockbox']:
                        if 'lockbox' in (items_sewer):
                            print("You need to take the box before you can examine it.")
                if action in ['talk','speak','pray']:
                    if item in ['shrine','altar']:
                        print("At first, you simply say 'Hello' to the altar, but before you know it you're talking about everything from your childhood to your current situation.")
                        decision=str.lower(input(fileroutes.cultist_conversation))
                        if decision in ['y','yes']:
                            room1.location='sacrifice'
                            print("'Very good', she replies. 'Follow me'.")
                        elif decision not in ['y','yes']:
                            room1.location='field'
                            print("She is quiet for a moment, before saying softly, 'You aren't really a believer are you?' Before you can act, she lashes out with a dagger.")
                            if 'sword' in (inventory):
                                functions.take_damage(health)
                                print("She grazes you, but you pull out your sword and knock her away, buying yourself time to run down the tunnel.")
                            if 'dagger' in (inventory):
                                if 'sword' not in (inventory):
                                    functions.take_damage(health)
                                    functions.take_damage(health)
                                    print("She cuts you, but you pull out your dagger and scare her away, buying yourself time to run down the tunnel.")
                            if 'sword' not in (inventory) and 'dagger' not in (inventory):
                                functions.take_damage(health)
                                functions.take_damage(health)
                                functions.take_damage(health)
                                print("She cuts you deeply, but you manage to run away down the tunnel.")
                    if item in ['cultist','cultists','figure','figures']:
                        print("You begin walking toward them, but instantly feel an intense sense of dread. You decide to leave them be.")
                    if item in ['body','corpse']:
                        print("Dead men do not speak, unfortunately.")
                if action in ['use','open']:
                    if item in ['lockbox','box']:
                        if 'lockbox' not in (inventory):
                            print("You'll need to take the box if you want to search it.")
                    if item=='key':
                        if 'lockbox' not in (inventory) and 'note 2' not in (inventory):
                            print("You have nothing to use the key on.")
                    if item in ['body','corpse']:
                        print("Gross.")
                    if item in ['shrine','altar']:
                        print("At first, you simply say 'Hello' to the altar, but before you know it you're talking about everything from your childhood to your current situation.")
                        decision=str.lower(input(fileroutes.cultist_conversation))
                        if decision in ['y','yes']:
                            room1.location='sacrifice'
                            print("'Very good', she replies. 'Follow me'.")
                        elif decision not in ['y','yes']:
                            room1.location='field'
                            print("She is quiet for a moment, before saying softly, 'You aren't really a believer are you?' Before you can act, she lashes out with a dagger.")
                            if 'sword' in (inventory):
                                functions.take_damage(health)
                                print("She grazes you, but you pull out your sword and knock her away, buying yourself time to run down the tunnel.")
                            if 'dagger' in (inventory):
                                if 'sword' not in (inventory):
                                    functions.take_damage(health)
                                    functions.take_damage(health)
                                    print("She cuts you, but you pull out your dagger and scare her away, buying yourself time to run down the tunnel.")
                            if 'sword' not in (inventory) and 'dagger' not in (inventory):
                                functions.take_damage(health)
                                functions.take_damage(health)
                                functions.take_damage(health)
                                print("She cuts you deeply, but you manage to run away down the tunnel.")
                if action in ['fuck','bang']:
                    if item in ['body','corpse']:
                        print("You should seek professional help.")
                if action in ['take','grab']:
                    if item in ['box','lockbox']:
                        if 'lockbox' in items_sewer:
                            print("Taken.")
                            items_sewer.remove('lockbox')
                            inventory.append('lockbox')
                if action in ['go','walk','move']:
                    if item=='south':
                        room1.location='field'
                        if 'sword' in (inventory):
                            functions.take_damage(health)
                            print(fileroutes.spider_attack)
                            print("Luckily you have a sword. You fight it off and are barely scratched.")
                        if 'dagger' in (inventory) and 'sword' not in (inventory):
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print(fileroutes.spider_attack)
                            print("Your dagger isn't much, but it will have to do. After a hard fight, you defeat it, but are injured.")
                        if 'torch' in (inventory) and 'dagger' not in (inventory) and 'sword' not in (inventory):
                            functions.take_damage(health)
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print(fileroutes.spider_attack)
                            print("You try to fend it off with your torch, but it doesn't help much. The ensuing fight is brutal.")
                        if 'torch' not in (inventory) and 'sword' not in (inventory) and 'dagger' not in (inventory):
                            functions.take_damage(health)
                            functions.take_damage(health)
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print(fileroutes.spider_attack)
                            print("Since you have nothing to defend yourself, the fight is devastating.")
                    if item=='north':
                        room1.location='west hall'
                        print("You go back up the stairs and find yourself in a dark hallway.")
                        if 'gone' in (room_easthall.monster):
                            print("That's strange... you're not sure if you came from here.")
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='pray':
                print("You'll have to tell me what you'd like to pray to.")
            if player_choice=='look':
                print(fileroutes.sewer_look)
            if player_choice=='south':
                room1.location='field'
                if 'sword' in (inventory):
                    functions.take_damage(health)
                    print(fileroutes.spider_attack)
                    print("Luckily you have a sword. You fight it off and are barely scratched.")
                if 'dagger' in (inventory) and 'sword' not in (inventory):
                    functions.take_damage(health)
                    functions.take_damage(health)
                    print(fileroutes.spider_attack)
                    print("Your dagger isn't much, but it will have to do. After a hard fight, you defeat it, but are injured.")
                if 'torch(lit)' in (inventory) and 'dagger' not in (inventory) and 'sword' not in (inventory):
                    functions.take_damage(health)
                    functions.take_damage(health)
                    functions.take_damage(health)
                    print(fileroutes.spider_attack)
                    print("You try to fend it off with your torch, but it doesn't help much. The ensuing fight is brutal.")
                if 'torch(lit)' not in (inventory) and 'sword' not in (inventory) and 'dagger' not in (inventory):
                    functions.take_damage(health)
                    functions.take_damage(health)
                    functions.take_damage(health)
                    functions.take_damage(health)
                    print(fileroutes.spider_attack)
                    print("Since you have nothing to defend yourself with, the fight is devastating.")
            if player_choice=='north':
                room1.location='west hall'
                print("You go back up the stairs and find yourself in a dark hallway.")
                if 'gone' in (room_easthall.monster):
                    print("That's strange... you're not sure if you came from here.")
        if player_choice.count(' ')>1:
            action=""
            item=""
    return player_choice, action or None, item or None
