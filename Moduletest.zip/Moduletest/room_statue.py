#Working on putting the jewels into the statue now.
import threading
from threading import Timer
import fileroutes
import functions
import room1
location=room1.location
inventory=functions.inventory
health=room1.health
jewels=room1.jewels
jewel=[]
eyes=[]
riddle=[1]
items_statue=['statue','voice','wall','walls','floor','floors','ceiling','north','south','east','west']
def riddle_timeout():
    functions.take_damage(health)
    print(" ")
    print('"Too slow", the voice says with a hint of sadness. Your throat constricts as a terrible force briefly racks your body. You feel weak.\n (Press ENTER for next question)')
    if health!=[]:
        functions.health_tracker(health)
        riddle.append(max(riddle)+1)
    if health==[]:
        riddle.clear()
    riddles(eyes)
def riddle_wrong():
    functions.take_damage(health)
    print(" ")
    if max(riddle)==1:
        print('"Wrong", the voice says with a hint of disappointment. "The men are musicians and are being paid to play.')
    if max(riddle)==2:
        print('"Wrong", the voice says with a hint of disappointment. "There are three brothers and four sisters, making seven siblings and a family of nine."')
    if max(riddle)==3:
        print('"Wrong", the voice says with a hint of disappointment. "A lion that has not eaten for a month is likely dead."')
    print('Your throat constricts as a terrible force briefly racks your body. You feel weak.')
    if health!=[]:
        functions.health_tracker(health)
        riddle.append(max(riddle)+1)
    if health==[]:
        riddle.clear()
    riddles(eyes)
def riddles(n):
    if len(n)>=3:
        print(" ")
        if riddle!=[]:
            if max(riddle)==1:
                keywords=['music','musicians','musician','instrument','instruments','band']
                timeout=50
                t=Timer(timeout, riddle_timeout)
                t.start()
                answer=str.lower(input(fileroutes.riddle1))
                t.cancel()
                words=answer.split()
            if max(riddle)==2:
                keywords=['nine','9']
                timeout=40
                t=Timer(timeout, riddle_timeout)
                t.start()
                prompt=input(fileroutes.riddle2)
                answer=str.lower(prompt)
                t.cancel()
                words=answer.split()
            if max(riddle)==3:
                keywords=['center','middle','lion','central']
                timeout=40
                t=Timer(timeout, riddle_timeout)
                t.start()
                prompt=input(fileroutes.riddle3)
                answer=str.lower(prompt)
                t.cancel()
                words=answer.split()
            if max(riddle)>=4:
                room1.location='treasure'
                print(fileroutes.riddles_solved)
            print(" ")
            if max(riddle)<=3:
                for i in words:
                    if i in keywords:
                        riddle.append(max(riddle)+1)
                        print('"Correct", the voice says with some satisfaction.')
                        riddles(eyes)
            if max(riddle)<=3:
                riddle_wrong()
def statue(n):
    if n=='statue':
        global location
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')>1:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if action=='look':
                print(fileroutes.statue)
                if 'note 2' in (inventory):
                    print("It closely resembles a depiction you saw on a shrine earlier.")
                if len(eyes)==1:
                    print(" ")
                    print("The statue's left eye has a beautiful jewel in it.")
                if len(eyes)==2:
                    print(" ")
                    print("Two of the statue's eyes have beautiful jewels in them.")
                if len(eyes)==3:
                    print(" ")
                    print("The three jeweled eyes of the statue glow with a fiery energy.")
            if item in (items_statue+inventory):
                if action in ('check','examine'):
                    if item in ('wall','walls','floor','floors','ceiling'):
                        print("The room is cramped and featureless except for the creepy statue in front of you.")
                    if item=='statue':
                        print("It's a stone statue of a horned creature. It has three eye sockets carved into its face.")
                        if len(eyes)==1:
                            print("The statue's left eye has a beautiful jewel in it.")
                        if len(eyes)==2:
                            print("Two of the statue's eyes have beautiful jewels in them.")
                        if len(eyes)==3:
                            print("The three jeweled eyes of the statue glow with a fiery energy.")
                if action in ('take','grab'):
                    if item=='jewel':
                        items_statue.remove('jewel')
                        inventory.append('jewel')
                        print("Taken.")
                if action in ('use','put','place'):
                    if item=='jewel':
                        if 'jewel' in (inventory):
                            if len(eyes)<3:
                                eyes.append('eye')
                                inventory.remove('jewel')
                                if len(eyes)==1:
                                    print(fileroutes.statue_firsteye)
                                if len(eyes)==2:
                                    print("You place a second jewel in the statue's right eye.")
                                if len(eyes)==3:
                                    print(fileroutes.statue_thirdeye)
                                    play=str.lower(input(fileroutes.statue_firsttalk))
                                    if play in ('y','yes'):
                                        riddles(eyes)
                                    if play in ('n','no'):
                                        print("You decide against playing the voice's game for now.")
                if action in ('talk','speak'):
                    if item in ('statue','voice'):
                        print("You approach the statue once again.")
                        riddles(eyes)
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                print(fileroutes.statue)
                if 'note 2' in (inventory):
                    print("It closely resembles a depiction you saw on a shrine earlier.")
                if len(eyes)==1:
                    print(" ")
                    print("The statue's left eye has a beautiful jewel in it.")
                if len(eyes)==2:
                    print(" ")
                    print("Two of the statue's eyes have beautiful jewels in them.")
                if len(eyes)==3:
                    print(" ")
                    print("The three jeweled eyes of the statue glow with a fiery energy.")
            if player_choice=='north':
                room1.location='exit choice'
                print("You walk all the way back up the hallway.")
    return player_choice, action or None, item or None
