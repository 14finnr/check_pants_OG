import fileroutes
import functions
import room1
location=room1.location
inventory=functions.inventory
jewels=room1.jewels
health=room1.health
def valley(n):
    if n=='valley':
        global location
        action=""
        item=""
        print(fileroutes.valley)
        player_choice=input(" ")
    return player_choice, action or None, item or None
