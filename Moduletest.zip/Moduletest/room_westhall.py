import fileroutes
import functions
import room1
import room_guard
location=room1.location
inventory=functions.inventory
jewels=room1.jewels
health=room1.health
lighter_westhall=[]
items_westhall=['torch','wall','walls','sound','sounds','voice','voices','whisper','whispers','whispering','water','river','stream','stairs','north','south','west','east']
def west_hall(n):
    if n=='west hall':
        coin_check=0
        global location
        player_choice=str.lower(input("What would you like to do?: "))
        functions.instructions(player_choice.split())
        functions.inv_check(player_choice.split())
        room1.vial(player_choice.split())
        room1.potion(player_choice.split())
        functions.item_check(player_choice)
        print(" ")
        if player_choice.count(' ')==1 and len(player_choice.split())!=2:
            action=""
            item=""
        if player_choice.count(' ')==1 and len(player_choice.split())==2:
            action=player_choice.split()[0]
            item=player_choice.split()[1]
            if action=='look':
                if 'sound' in (items_westhall):
                    print(fileroutes.left_hall_look)
                    if 'torch(lit)' in (inventory):
                        print("The whispers seem to almost hiss every time you move your torch about.")
                elif 'sound' not in (items_westhall):
                    print(fileroutes.left_hall_look_nosound)
                    if 'torch(lit)' in (inventory):
                        print("Your torch helps you see that the stairs are to the south and stream flows to the north.")
            if item in (items_westhall+inventory):
                if action in ['examine','check']:
                    if item in ['wall','walls']:
                        items_westhall.remove('wall')
                        items_westhall.remove('walls')
                        items_westhall.append('coin')
                        items_westhall.append('coins')
                        items_westhall.append('dagger')
                        items_westhall.append('knife')
                        print(fileroutes.westhall_check_wall)
                    if item in ['sound','sounds','voice','voices','whisper','whispers']:
                        print("You can't tell whether the whispers are real or imaginary, but you feel that they are trying to tell you something.")
                    if item in ['water','river','stream']:
                        print("You find a small underground stream flowing to the north. It's cold, but you could still swim in it.")
                    if item=='stairs':
                        if lighter_westhall==[]:
                            print("The stairs are steep and slippery, leading south into the darkness. They look treacherous.")
                        elif 'lighter' in lighter_westhall:
                            print("The stairs are steep and slippery, leading south into the darkness, but your lighter helps you see a bit better.")
                if action in ['light','use']:
                    if item=='lighter':
                        lighter_westhall.append('lighter')
                        print("You strike your lighter, making it a bit easier to see.")
                        if 'sound' in (items_westhall):
                            print("As if in response, the whispering becomes more intense, and you can't escape the feeling that something is trying to communicate with you.")
                    if item=='torch':
                        if 'torch(lit)' in (inventory):
                            lighter_westhall.append('lighter')
                            print("You swing your torch around a bit.")
                            if 'sound' in (items_westhall):
                                print("As if in response, the whispering becomes more intense, and you can't escape the feeling that something is trying to communicate with you.")
                if action in ['speak','talk','listen']:
                    if item in ['sound','sounds','voice','voices','whisper','whispers','whispering']:
                        items_westhall.remove('sound')
                        items_westhall.remove('sounds')
                        items_westhall.remove('voice')
                        items_westhall.remove('voices')
                        items_westhall.remove('whisper')
                        items_westhall.remove('whispers')
                        print(fileroutes.shadow_response)
                        question_1=str.lower(input("Are you afraid of me?: "))
                        print(" ")
                        if question_1 in ['y','yes']:
                            question_2=str.lower(input("'Smart', the voice whispers. 'Now a more important question. Do you value your health or your wealth more?': "))
                            print(" ")
                            if question_2 in ['health','my health']:
                                room1.health.append(max(room1.health)+1)
                                print("'Very well', the voice replies. 'Take this gift. You will need it'. And then the whispering is gone.")
                                print("You feel a strange warmth inside you. It fills you with determination.")
                            if question_2 in ['wealth','my wealth']:
                                items_westhall.append('jewel')
                                items_westhall.append('gem')
                                print("'Very well', the voice replies. 'Take this gift. You will need it'. And then the whispering is gone.")
                                print("You hear the clink of something hard falling on the floor. Looking down, you find a beautiful blue jewel on the floor.")
                            if question_2 not in ['health','my health','wealth','my wealth']:
                                functions.take_damage(room1.health)
                                functions.take_damage(room1.health)
                                print("'That's a shame', the voice replies softly. You then double over in pain, groaning in the darkness.")
                                print("When you finally get up, you don't know how much time has passed.")
                        elif question_1 not in ['y','yes']:
                            functions.take_damage(room1.health)
                            functions.take_damage(room1.health)
                            print("'That's a shame', the voice replies softly. You then double over in pain, groaning in the darkness.")
                            print("When you finally get up, you don't know how much time has passed.")
                if action in ['hit','punch','attack']:
                    if item in ['sound','sounds','voice','voices','whisper','whispers']:
                        items_westhall.remove('sound')
                        items_westhall.remove('sounds')
                        items_westhall.remove('voice')
                        items_westhall.remove('voices')
                        items_westhall.remove('whisper')
                        items_westhall.remove('whispers')
                        functions.take_damage(room1.health)
                        functions.take_damage(room1.health)
                        print("You feel a sharp pain, as if being punished by a vengeful God. You double over, groaning. When you finally get up you don't know how much time has passed.")
                        print("It seems that your friends in the darkness have gone quiet.")
                    elif item not in ['sound','sounds','voice','voices']:
                        functions.take_damage(room1.health)
                        print("Swinging wildly into the darkness, your fist meets nothing but stone.")
                if action in ['take','grab']:
                    if item in ['coin','coins']:
                        if 'coin' in (items_westhall):
                            items_westhall.remove('coin')
                            items_westhall.remove('coins')
                            print("Taken.")
                            while coin_check<3:
                                coin_check+=1
                                inventory.append('coin')
                    if item in ['dagger','knife']:
                        if 'dagger' in (items_westhall):
                            items_westhall.remove('dagger')
                            items_westhall.remove('knife')
                            inventory.append('dagger')
                            print("Taken.")
                    if item in ['jewel','gem']:
                        if 'jewel' in (items_westhall):
                            items_westhall.remove('jewel')
                            items_westhall.remove('gem')
                            inventory.append('jewel')
                            jewels.append('blue')
                            print("Taken.")
                if action in ['go','move','walk','swim']:
                    if item=='west':
                        print("There is only a hard wall to your west.")
                    if item in ['east','back']:
                        if 'sound' not in (items_westhall):
                            print("You head back the way you came.")
                            print(fileroutes.hallway)
                            room1.location='hall choice'
                        if 'sound' in (items_westhall):
                            print("When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")
                    if item in ['south','north']:
                        if 'sound' in (items_westhall):
                            print("When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")
                        elif 'sound' not in (items_westhall):
                            if item=='south':
                                room1.location='sewer'
                                if 'lighter' in (lighter_westhall):
                                    print("The lighter isn't much, but it's enough. You descend the stairs carefully.")
                                    print(fileroutes.sewer_go)
                                elif 'lighter' not in (lighter_westhall):
                                    functions.take_damage(health)
                                    print("You descend the stairs one at a time, but cannot help slipping and hurting yourself in the darkness.")
                                    print(fileroutes.sewer_go)
                            if item=='north':
                                if functions.guard==[]:
                                    room1.location='guard post'
                                    functions.take_damage(health)
                                    functions.take_damage(health)
                                    print(fileroutes.river_ride)
                                    print(fileroutes.guard_river_convo)
                                    if 'torch(lit)' in (inventory):
                                        inventory.remove('torch(lit)')
                                        inventory.append('torch(unlit)')
                                if functions.guard!=[]:
                                    print("You know that the water is freezing and dangerous. Better stay away from it.")
        if player_choice.count(' ')==0:
            action=""
            item=""
            if player_choice=='look':
                if 'sound' in (items_westhall):
                    print(fileroutes.left_hall_look)
                    if 'torch(lit)' in (inventory):
                        print("The whispers seem to almost hiss every time you move your torch about.")
                elif 'sound' not in (items_westhall):
                    print(fileroutes.left_hall_look_nosound)
                    if 'torch(lit)' in (inventory):
                        print("Your torch helps you see that the stairs are to the south and stream flows to the north.")
            if player_choice in ('listen','speak','talk'):
                print("You'll have to specify what you want to ",player_choice," to.")
            if player_choice=='west':
                print("There is only a hard wall to your west.")
            if player_choice in ['east','back']:
                if 'sound' not in (items_westhall):
                    print("You head back the way you came.")
                    print(fileroutes.hallway)
                    room1.location='hall choice'
                if 'sound' in (items_westhall):
                    print("When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")
            if player_choice in ['south','north']:
                if 'sound' in (items_westhall):
                    print("When you try to move, the whispers become more intense and seem to surround you, as if trying to tell you something.")
                if 'sound' not in (items_westhall):
                    if player_choice=='south':
                        room1.location='sewer'
                        if lighter_westhall==[]:
                            functions.take_damage(health)
                            print("You slip on your way down the stairs, hurting yourself.")
                        if lighter_westhall!=[]:
                            print("You descend the stairs carefully.")
                        print(fileroutes.sewer_go)
                    if player_choice=='north':
                        if functions.guard==[]:
                            room1.location='guard post'
                            functions.take_damage(health)
                            functions.take_damage(health)
                            print(fileroutes.river_ride)
                            print(fileroutes.guard_river_convo)
                        if functions.guard!=[]:
                            print("You know that the water is freezing and dangerous. Better stay away from it.")
        if player_choice.count(' ')>1:
            action=""
            item=""
    return player_choice, action or None, item or None
